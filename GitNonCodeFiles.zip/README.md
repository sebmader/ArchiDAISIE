# ArchiDAISIE

Branch|[![Travis CI logo](pics/TravisCI.png)](https://travis-ci.org)|[![Codecov logo](pics/Codecov.png)](https://www.codecov.io)
---|---|---
`master`|[![Build Status](https://travis-ci.org/sebmader/ArchiDAISIE.svg?branch=master)](https://travis-ci.org/sebmader/ArchiDAISIE) | [![codecov.io](https://codecov.io/github/sebmader/ArchiDAISIE/coverage.svg?branch=master)](https://codecov.io/github/sebmader/ArchiDAISIE?branch=master)
`develop`|[![Build Status](https://travis-ci.org/sebmader/ArchiDAISIE.svg?branch=develop)](https://travis-ci.org/sebmader/ArchiDAISIE) | [![codecov.io](https://codecov.io/github/sebmader/ArchiDAISIE/coverage.svg?branch=develop)](https://codecov.io/github/sebmader/ArchiDAISIE?branch=develop)

ArchiDAISIE.
